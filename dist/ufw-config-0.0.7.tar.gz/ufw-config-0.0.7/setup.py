# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['ufw_config']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'ufw-config',
    'version': '0.0.7',
    'description': 'A Tool for opening and closing ports with UFW.',
    'long_description': None,
    'author': 'NeonDevelopment',
    'author_email': 'root@neon-is.fun',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.6,<4.0',
}


setup(**setup_kwargs)
